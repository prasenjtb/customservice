<?php
 
/**
 
 * @file
 
 * Contains \Drupal\customconfig\Form\CustomConfigForm.
 
 */
 
namespace Drupal\customconfig\Form;
 
use Drupal\Core\Form\ConfigFormBase;
 
use Drupal\Core\Form\FormStateInterface;
 
class CustomConfigForm extends ConfigFormBase {
 
  /**
 
   * {@inheritdoc}
 
   */
 
  public function getFormId() {
 
    return 'customconfig_config_form';
 
  }
 
  /**
 
   * {@inheritdoc}
 
   */
 
  public function buildForm(array $form, FormStateInterface $form_state) {
 
    $form = parent::buildForm($form, $form_state);
 
    $config = $this->config('customconfig.settings');
    
    $form['country'] = array(
      '#type' => 'textfield',
      '#title' => $this->t('Country'),
      '#default_value' => $config->get('customconfig.country'),
      '#required' => TRUE, 
    );
    
    $form['city'] = array(
      '#type' => 'textfield',
      '#title' => $this->t('City'),
      '#default_value' => $config->get('customconfig.city'),
      '#required' => TRUE, 
    );
    
    $timezones_arr = array();
    $timezones_arr['Chicago'] = 'America/Chicago';
    $timezones_arr['New_York'] = 'America/New_York';
    $timezones_arr['Tokyo'] = 'Asia/Tokyo';
    $timezones_arr['Dubai'] = 'Asia/Dubai';
    $timezones_arr['Kolkata'] = 'Asia/Kolkata';
    $timezones_arr['Amsterdam'] = 'Europe/Amsterdam';
    $timezones_arr['Oslo'] = 'Europe/Oslo';
    $timezones_arr['London'] = 'Europe/London';
   
	$form['timezone'] = array(
      '#type' => 'select',
      '#title' => $this->t('Timezone'),
      '#options' => $timezones_arr,
      '#default_value' => $config->get('customconfig.timezone'),
      '#required' => TRUE,
    );
    
    
    return $form;
 
  }
 
  /**
 
   * {@inheritdoc}
 
   */
 
  public function submitForm(array &$form, FormStateInterface $form_state) {
 
    $config = $this->config('customconfig.settings');
	
	$config->set('customconfig.country', $form_state->getValue('country'));
	$config->set('customconfig.city', $form_state->getValue('city'));
	$config->set('customconfig.timezone', $form_state->getValue('timezone'));
	 
    $config->save();
 
    return parent::submitForm($form, $form_state);
 
  }
 
  /**
 
   * {@inheritdoc}
 
   */
 
  protected function getEditableConfigNames() {
 
    return [
 
      'customconfig.settings',
 
    ];
 
  }
 
}
