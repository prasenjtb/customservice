<?php
/**
 * @file
 * Contains \Drupal\customconfig\Plugin\Block\timezoneBlock.
 */
namespace Drupal\customconfig\Plugin\Block;
use Drupal\Core\Block\BlockBase;
use Drupal\Core\Access\AccessResult;
use Drupal\Core\Session\AccountInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
/**
 * Provides a 'Timezone' block.
 *
 * @Block(
 *   id = "timezone_block",
 *   admin_label = @Translation("timezone block"),
 *   category = @Translation("Custom timezone block")
 * )
 */
class timezoneBlock extends BlockBase {
  /**
   * {@inheritdoc}
   */
     public function build() {

			   
		$service = \Drupal::service('customconfig.demo_service');
		$service_zone = $service->getDemoValue();
	   
		//$dateobj = new DateTime("now", new DateTimeZone('America/New_York'));
		//$timezonedate = $dateobj->format('Y-m-d H:i:s');
		
		if($service_zone == 'Chicago')
		{
			$timezone_name = 'America/Chicago';	
		}
		elseif($service_zone == 'New_York')
		{
			$timezone_name = 'America/New_York';	
		}	
		elseif($service_zone == 'Tokyo')
		{
			$timezone_name = 'Asia/Tokyo';	
		}
		elseif($service_zone == 'Dubai')
		{
			$timezone_name = 'Asia/Dubai';	
		}
		elseif($service_zone == 'Kolkata')
		{
			$timezone_name = 'Asia/Kolkata';	
		}
		elseif($service_zone == 'Amsterdam')
		{
			$timezone_name = 'Europe/Amsterdam';	
		}
		elseif($service_zone == 'Oslo')
		{
			$timezone_name = 'Europe/Oslo';	
		}
		elseif($service_zone == 'London')
		{
			$timezone_name = 'Europe/London';	
		}
		
		
		date_default_timezone_set($timezone_name);
		$timezonedate = date('d M, Y H:i') ;
		
	   //$timezonedate = date("Y-m-d h:i:s");
	   
		return array(
			//'#markup' => t('Admin Timezone : <b>@value</b> - @time', array('@value' => $service_zone, '@time' => $timezonedate)),
			'#theme' => 'timezone_block',
			'#timezone' => $service_zone,
			'#timezonedate' => $timezonedate,
		);
	}
	
	
	/**
   * {@inheritdoc}
   */
  protected function blockAccess(AccountInterface $account) {
    return AccessResult::allowedIfHasPermission($account, 'access content');
  }
  
}
