<?php

/**
 * @file
 * Contains Drupal\customconfig\DemoService.
 */

namespace Drupal\customconfig;

class DemoService {
  
  protected $demoTimezone;
  
  public function __construct() {
    //$this->demo_city = 'Kolkata';
    //$this->demo_country = 'Kolkata';
    $this->demoTimezone = 'Asia/Kolkata';
  }
  
  public function getDemoValue() {
	  
	 $config = \Drupal::config('customconfig.settings');
	
	//$this->demo_country = $config->set('customconfig.country', $form_state->getValue('country'));
	//$this->demo_city = $config->set('customconfig.city', $form_state->getValue('city'));
	$this->demoTimezone = $config->get('customconfig.timezone'); 
	  
	  
    return $this->demoTimezone;
  }
  
}
